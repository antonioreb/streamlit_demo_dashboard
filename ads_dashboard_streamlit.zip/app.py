
import streamlit as st
import pandas as pd
from logic.metrics import add_metrics
from utils.filters import apply_global_filters

st.set_page_config(page_title="Ads Performance Dashboard", layout="wide")

@st.cache_data
def load_data():
    df = pd.read_csv("data/ads_data.csv", parse_dates=["date"])
    return add_metrics(df)

df = load_data()

st.title("📊 Multi-Channel Advertising Dashboard")
st.markdown("Use the sidebar to filter data and navigate pages.")
