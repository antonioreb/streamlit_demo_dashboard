
import pandas as pd
import numpy as np
from datetime import datetime

np.random.seed(42)
dates = pd.date_range(end=datetime.today(), periods=90)
channels = ["Amazon", "Google", "Meta"]
campaign_types = ["Auto", "Manual"]
products = ["SKU_A", "SKU_B", "SKU_C"]

rows = []
for date in dates:
    for channel in channels:
        for campaign_type in campaign_types:
            for product in products:
                impressions = np.random.randint(500, 5000)
                ctr = np.random.uniform(0.005, 0.05)
                clicks = int(impressions * ctr)
                cpc = np.random.uniform(0.2, 1.5)
                cost = clicks * cpc
                cvr = np.random.uniform(0.01, 0.15)
                orders = int(clicks * cvr)
                aov = np.random.uniform(20, 60)
                revenue = orders * aov

                rows.append([
                    date, channel, campaign_type,
                    f"{channel}_{campaign_type}_{product}",
                    f"keyword_{np.random.randint(1,20)}",
                    np.random.choice(["Exact", "Phrase", "Broad"]),
                    product,
                    impressions, clicks, cost, orders, revenue
                ])

df = pd.DataFrame(rows, columns=[
    "date","channel","campaign_type","campaign",
    "keyword","match_type","product",
    "impressions","clicks","cost","orders","revenue"
])

df.to_csv("ads_data.csv", index=False)
