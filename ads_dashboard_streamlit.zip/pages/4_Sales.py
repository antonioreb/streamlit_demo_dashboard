
import streamlit as st
from utils.filters import apply_global_filters

st.header("🛒 Sales")
df_f = apply_global_filters(df)

prod = df_f.groupby("product").sum(numeric_only=True)
prod["roas"] = prod.revenue / prod.cost
st.bar_chart(prod["revenue"])
st.dataframe(prod)
