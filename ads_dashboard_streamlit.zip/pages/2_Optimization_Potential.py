
import streamlit as st
from logic.optimization import optimization_flags
from utils.filters import apply_global_filters

st.header("🧠 Optimization Potential")
df_f = apply_global_filters(df)
opt_df = optimization_flags(df_f)

st.dataframe(
    opt_df[opt_df.optimization_action != "OK"]
    [["campaign","keyword","cost","orders","roas","optimization_action"]]
    .sort_values("cost", ascending=False)
)
