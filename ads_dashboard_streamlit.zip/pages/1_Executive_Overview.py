
import streamlit as st
from utils.filters import apply_global_filters
from utils.charts import spend_vs_revenue

st.header("📈 Executive Overview")
df_f = apply_global_filters(df)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Spend", f"€{df_f.cost.sum():,.0f}")
col2.metric("Revenue", f"€{df_f.revenue.sum():,.0f}")
col3.metric("ROAS", f"{df_f.revenue.sum()/df_f.cost.sum():.2f}")
col4.metric("Orders", int(df_f.orders.sum()))

st.altair_chart(spend_vs_revenue(df_f), use_container_width=True)
