
import streamlit as st
from utils.filters import apply_global_filters

st.header("🔑 Keywords")
df_f = apply_global_filters(df)

kw = df_f.groupby("keyword").sum(numeric_only=True)
kw["roas"] = kw.revenue / kw.cost
st.dataframe(kw.sort_values("revenue", ascending=False))
