
import streamlit as st
import pandas as pd

def apply_global_filters(df):
    st.sidebar.header("🔎 Global Filters")
    date_min, date_max = df.date.min(), df.date.max()

    date_range = st.sidebar.date_input(
        "Date range", [date_min, date_max],
        min_value=date_min, max_value=date_max
    )

    channels = st.sidebar.multiselect(
        "Channel", df.channel.unique(), df.channel.unique()
    )

    campaign_types = st.sidebar.multiselect(
        "Campaign Type", df.campaign_type.unique(), df.campaign_type.unique()
    )

    products = st.sidebar.multiselect(
        "Product", df.product.unique(), df.product.unique()
    )

    return df[
        (df.date.between(pd.to_datetime(date_range[0]), pd.to_datetime(date_range[1])))
        & (df.channel.isin(channels))
        & (df.campaign_type.isin(campaign_types))
        & (df.product.isin(products))
    ]
