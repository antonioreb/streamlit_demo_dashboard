
import altair as alt

def spend_vs_revenue(df):
    agg = df.groupby("date")[["cost","revenue"]].sum().reset_index()
    base = alt.Chart(agg).encode(x="date:T")
    return alt.layer(
        base.mark_line().encode(y="cost:Q"),
        base.mark_line(color="green").encode(y="revenue:Q")
    ).resolve_scale(y="independent")
