
def add_metrics(df):
    df["ctr"] = df["clicks"] / df["impressions"]
    df["cvr"] = df["orders"] / df["clicks"]
    df["cpc"] = df["cost"] / df["clicks"]
    df["roas"] = df["revenue"] / df["cost"]
    df["acos"] = df["cost"] / df["revenue"]
    return df
