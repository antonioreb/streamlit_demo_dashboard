
def optimization_flags(df, roas_target=3, min_spend=20):
    actions = []
    for _, row in df.iterrows():
        if row["cost"] > min_spend and row["orders"] == 0:
            actions.append("NEGATIVE_CANDIDATE")
        elif row["roas"] >= roas_target and row["campaign_type"] == "Auto":
            actions.append("PROMOTE_TO_MANUAL")
        elif row["roas"] < roas_target and row["cost"] > min_spend:
            actions.append("OPTIMIZE_BID")
        else:
            actions.append("OK")
    df["optimization_action"] = actions
    return df
